# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=8.3.2,<9.0.0', 'PyQt6>=6.1.1,<7.0.0', 'progress>=1.6,<2.0']

entry_points = \
{'console_scripts': ['pyqtasync_gui = src.main_gui:main']}

setup_kwargs = {
    'name': 'src',
    'version': '0.1.0',
    'description': 'Create a GIF file of the screenshot.',
    'long_description': None,
    'author': 'mochisue',
    'author_email': 'motoki32925@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
